export interface DatasetStatus {
  database_exists: boolean;
  total_rows?: number;
  total_quantity?: number;
  total_sales?: number;
  average_transaction?: number;
  filename?: string;
  uploaded_at?: string;
}

export interface KPIStats {
  total_sales: number;
  total_quantity: number;
  total_transactions: number;
  average_transaction: number;
}

export interface OverviewData {
  dataset: {
    rows: number;
    start: string;
    end: string;
  };
  kpis: KPIStats;
  trends: {
    revenue?: number;
    units?: number;
    transactions?: number;
    avg?: number;
    label?: string;
  };
  weekly: { date: string; revenue: number }[];
  monthly: {
    month: string;
    total_revenue: number;
    avg_revenue: number;
    partial: boolean;
  }[];
  categories: { category: string; sales: number }[];
  segments: {
    age: { segment: string; count: number; revenue: number }[];
    gender: { segment: string; count: number; revenue: number }[];
  };
}

export interface SalesAnalysisData {
  trend: {
    weekly: { date: string; revenue: number }[];
    monthly: {
      month: string;
      total_revenue: number;
      avg_revenue: number;
      partial: boolean;
    }[];
  };
  stacked: {
    months: string[];
    series: { category: string; values: number[] }[];
  };
  categories: {
    category: string;
    revenue: number;
    share: number;
    units: number;
    orders: number;
    avg_order: number;
  }[];
  weekday: { day: string; avg_daily_revenue: number }[];
  insights: string[];
  partial_months_excluded: string[];
}

export interface ForecastData {
  history: { date: string; sales: number }[];
  data: {
    date: string;
    predicted: number;
    lower: number;
    upper: number;
  }[];
  model: string;
  mape: number;
  accuracy: number;
  next_month_predicted: number;
  partial_months_excluded: string[];
}

export interface AnomalyItem {
  date: string;
  value: number;
  expected: number;
  deviation: string;
  severity: 'High' | 'Medium';
  score: number;
}

export interface AnomaliesData {
  data: AnomalyItem[];
  total: number;
  threshold?: number;
}

export interface LLMProvider {
  id: string;
  label: string;
  model: string;
  configured: boolean;
  note: string;
  status_label?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  time: string;
  model?: string;
  provider?: string;
}
