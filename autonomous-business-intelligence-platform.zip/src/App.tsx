import React, { useState } from 'react';
import { DataProvider, useData } from './contexts/DataContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { Navbar } from './components/layout/Navbar';
import { AuthModal } from './components/auth/AuthModal';
import { HomepageView } from './views/HomepageView';
import { AuthView } from './views/AuthView';
import { ErrorView } from './views/ErrorView';
import { DashboardView } from './views/DashboardView';
import { UploadDatasetView } from './views/UploadDatasetView';
import { SalesAnalysisView } from './views/SalesAnalysisView';
import { ForecastAnomaliesView } from './views/ForecastAnomaliesView';
import { AskYourDataView } from './views/AskYourDataView';
import { ReportsView } from './views/ReportsView';
import { SettingsView } from './views/SettingsView';

function AppContent() {
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [sidebarHidden, setSidebarHidden] = useState<boolean>(() => {
    try {
      return localStorage.getItem('abip_sidebar_hidden') === 'true';
    } catch {
      return false;
    }
  });
  const { loaded, refresh, backendUp } = useData();

  const toggleSidebar = () => {
    setSidebarHidden((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('abip_sidebar_hidden', String(next));
      } catch {}
      return next;
    });
  };

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+B or Cmd+B to toggle sidebar visibility
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
        e.preventDefault();
        toggleSidebar();
      }
    };

    const handleExternalToggle = () => {
      try {
        setSidebarHidden(localStorage.getItem('abip_sidebar_hidden') === 'true');
      } catch {}
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('abip:sidebar-toggle', handleExternalToggle);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('abip:sidebar-toggle', handleExternalToggle);
    };
  }, []);

  // Redirect to upload view first when authenticated, or dashboard if dataset is active
  const handleAuthSuccess = () => {
    setCurrentTab(loaded ? 'dashboard' : 'upload');
  };

  // If on homepage, render full-bleed marketing and interactive demo homepage
  if (currentTab === 'home') {
    return (
      <>
        <HomepageView
          onLaunchPlatform={(tab = 'upload') => setCurrentTab(tab)}
        />
        <AuthModal onAuthSuccess={handleAuthSuccess} />
      </>
    );
  }

  // Public: Dedicated Split-Layout Sign In & Sign Up Screen
  if (currentTab === 'signin' || currentTab === 'signup') {
    return (
      <AuthView
        initialMode={currentTab}
        onNavigateHome={() => setCurrentTab('home')}
        onAuthSuccess={handleAuthSuccess}
      />
    );
  }

  // Public: 404 Discontinuity Screen
  if (currentTab === '404') {
    return (
      <ErrorView
        type="404"
        onNavigateHome={() => setCurrentTab('home')}
      />
    );
  }

  // Public: Server Unreachable / Offline Screen
  if (currentTab === 'offline') {
    return (
      <ErrorView
        type="offline"
        onNavigateHome={() => setCurrentTab('home')}
        onRetry={async () => {
          await refresh();
          if (backendUp) setCurrentTab('dashboard');
        }}
      />
    );
  }

  // Otherwise, render full Enterprise AI Platform workspace layout
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0f172a] text-slate-900 dark:text-slate-100 transition-colors font-sans">
      <Sidebar
        currentTab={currentTab}
        onSelectTab={(tab) => setCurrentTab(tab)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        sidebarHidden={sidebarHidden}
        onToggleSidebar={toggleSidebar}
      />

      <div
        className={`${
          sidebarHidden ? 'md:pl-0' : 'md:pl-64'
        } transition-[padding] duration-300 ease-in-out flex flex-col min-h-screen`}
      >
        <Navbar
          currentTab={currentTab}
          onOpenMobile={() => setMobileOpen(true)}
          sidebarHidden={sidebarHidden}
          onToggleSidebar={toggleSidebar}
          onGoToUpload={() => setCurrentTab('upload')}
          onGoToHome={() => setCurrentTab('home')}
          onGoToSettings={() => setCurrentTab('settings')}
        />

        <main className="flex-1 p-4 md:p-8">
          {currentTab === 'dashboard' && (
            <DashboardView onNavigate={(tab) => setCurrentTab(tab)} />
          )}
          {currentTab === 'upload' && (
            <UploadDatasetView onNavigate={(tab) => setCurrentTab(tab)} />
          )}
          {currentTab === 'sales-analysis' && (
            <SalesAnalysisView onNavigate={(tab) => setCurrentTab(tab)} />
          )}
          {currentTab === 'forecast-anomalies' && (
            <ForecastAnomaliesView onNavigate={(tab) => setCurrentTab(tab)} />
          )}
          {currentTab === 'ask-data' && (
            <AskYourDataView onNavigate={(tab) => setCurrentTab(tab)} />
          )}
          {currentTab === 'reports' && (
            <ReportsView onNavigate={(tab) => setCurrentTab(tab)} />
          )}
          {currentTab === 'settings' && <SettingsView />}
        </main>
      </div>

      <AuthModal onAuthSuccess={handleAuthSuccess} />
    </div>
  );
}

export default function App() {
  return (
    <DataProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </DataProvider>
  );
}
