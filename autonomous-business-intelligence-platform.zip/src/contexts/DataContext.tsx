import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { DatasetStatus } from '../types';

interface DataContextType {
  dataset: DatasetStatus | null;
  loaded: boolean;
  filename: string;
  ready: boolean;
  backendUp: boolean;
  refreshing: boolean;
  version: number;
  theme: 'dark' | 'light';
  setTheme: (mode: 'dark' | 'light') => void;
  toggleTheme: () => void;
  refresh: () => Promise<void>;
  uploadFile: (file: File) => Promise<any>;
  loadSample: () => Promise<any>;
  removeData: () => Promise<any>;
  downloadTemplate: () => void;
}

const DataContext = createContext<DataContextType | null>(null);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [dataset, setDataset] = useState<DatasetStatus | null>(null);
  const [ready, setReady] = useState(false);
  const [backendUp, setBackendUp] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [version, setVersion] = useState(0);

  // Initialize theme with safe localStorage and fallback to system preference
  const [theme, setThemeState] = useState<'dark' | 'light'>(() => {
    try {
      const saved = localStorage.getItem('abip_theme');
      if (saved === 'dark' || saved === 'light') return saved;
      if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        return 'dark';
      }
    } catch {
      // fallback
    }
    return 'dark';
  });

  const applyTheme = useCallback((mode: 'dark' | 'light') => {
    const root = document.documentElement;
    if (mode === 'dark') {
      root.classList.add('dark');
      root.style.colorScheme = 'dark';
    } else {
      root.classList.remove('dark');
      root.style.colorScheme = 'light';
    }
    try {
      localStorage.setItem('abip_theme', mode);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    applyTheme(theme);
  }, [theme, applyTheme]);

  const setTheme = useCallback(
    (mode: 'dark' | 'light') => {
      setThemeState(mode);
      applyTheme(mode);
    },
    [applyTheme]
  );

  const toggleTheme = useCallback(() => {
    setThemeState((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      return next;
    });
  }, [applyTheme]);

  const load = useCallback(async (bump = false) => {
    setRefreshing(true);
    try {
      const res = await fetch('/api/data/status');
      if (res.ok) {
        const data = await res.json();
        setDataset(data.database_exists && (data.total_rows || 0) > 0 ? data : null);
        setBackendUp(true);
      } else {
        setDataset(null);
      }
    } catch (e) {
      console.warn('Backend not reachable:', e);
      setDataset(null);
      setBackendUp(false);
    } finally {
      setRefreshing(false);
      setReady(true);
      if (bump) setVersion((v) => v + 1);
    }
  }, []);

  useEffect(() => {
    load(false);
  }, [load]);

  const refresh = useCallback(async () => {
    await load(true);
  }, [load]);

  const uploadFile = useCallback(
    async (file: File) => {
      const form = new FormData();
      form.append('file', file);
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: form,
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.detail || 'Upload failed.');
      }

      const data = await res.json();
      await load(true);
      return data;
    },
    [load]
  );

  const loadSample = useCallback(async () => {
    const res = await fetch('/api/data/sample', { method: 'POST' });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.detail || 'Could not load sample dataset.');
    }
    const data = await res.json();
    await load(true);
    return data;
  }, [load]);

  const removeData = useCallback(async () => {
    const res = await fetch('/api/data', { method: 'DELETE' });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.detail || 'Could not remove data.');
    }
    const data = await res.json();
    await load(true);
    return data;
  }, [load]);

  const downloadTemplate = useCallback(() => {
    window.location.href = '/api/data/template';
  }, []);

  const value = useMemo(
    () => ({
      dataset,
      loaded: Boolean(dataset && dataset.database_exists && (dataset.total_rows || 0) > 0),
      filename: dataset?.filename || '',
      ready,
      backendUp,
      refreshing,
      version,
      theme,
      setTheme,
      toggleTheme,
      refresh,
      uploadFile,
      loadSample,
      removeData,
      downloadTemplate,
    }),
    [
      dataset,
      ready,
      backendUp,
      refreshing,
      version,
      theme,
      setTheme,
      toggleTheme,
      refresh,
      uploadFile,
      loadSample,
      removeData,
      downloadTemplate,
    ]
  );

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
