import { NextRequest, NextResponse } from 'next/server';
import { databaseExists } from '@/server/db';
import { getAnomalies } from '@/server/analytics';

export async function GET(request: NextRequest) {
  if (!databaseExists()) {
    return NextResponse.json({ detail: 'No dataset has been uploaded yet.' }, { status: 404 });
  }
  const searchParams = request.nextUrl.searchParams;
  const limitQuery = searchParams.get('limit') ? parseInt(searchParams.get('limit')!, 10) : 500;
  const limit = isNaN(limitQuery) ? 500 : limitQuery;
  const thresholdQuery = searchParams.get('threshold') ? parseFloat(searchParams.get('threshold')!) : 2.0;
  const threshold = isNaN(thresholdQuery) ? 2.0 : thresholdQuery;
  return NextResponse.json(getAnomalies(undefined, limit, threshold));
}
