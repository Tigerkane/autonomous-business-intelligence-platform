import { getSalesRows } from './db';
import { SaleRow } from './types';

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function getDaysInMonth(year: number, monthIndex: number): number {
  return new Date(year, monthIndex + 1, 0).getDate();
}

function mean(nums: number[]): number {
  if (nums.length === 0) return 0;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

function median(nums: number[]): number {
  if (nums.length === 0) return 0;
  const sorted = [...nums].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function stdDev(nums: number[], ddof = 1): number {
  if (nums.length <= ddof) return 0;
  const m = mean(nums);
  const variance = nums.reduce((sum, n) => sum + Math.pow(n - m, 2), 0) / (nums.length - ddof);
  return Math.sqrt(variance);
}

// Simple 1D linear regression y = m*t + c
function fitLinear(y: number[]): (step: number) => number {
  const n = y.length;
  if (n === 0) return () => 0;
  if (n === 1) return () => y[0];

  let sumT = 0;
  let sumY = 0;
  let sumTY = 0;
  let sumT2 = 0;

  for (let t = 0; t < n; t++) {
    sumT += t;
    sumY += y[t];
    sumTY += t * y[t];
    sumT2 += t * t;
  }

  const denominator = n * sumT2 - sumT * sumT;
  if (denominator === 0) {
    const avg = sumY / n;
    return () => avg;
  }

  const slope = (n * sumTY - sumT * sumY) / denominator;
  const intercept = (sumY - slope * sumT) / n;

  return (step: number) => slope * step + intercept;
}

export function getMonthlyHistory(rows?: SaleRow[]) {
  const data = rows || getSalesRows();
  const monthMap = new Map<string, { total: number; dates: Set<string>; year: number; month: number }>();

  for (const row of data) {
    const ym = row.date.slice(0, 7);
    if (!monthMap.has(ym)) {
      const [y, m] = ym.split('-').map(Number);
      monthMap.set(ym, { total: 0, dates: new Set(), year: y, month: m });
    }
    const entry = monthMap.get(ym)!;
    entry.total += row.total_amount;
    entry.dates.add(row.date);
  }

  const sortedMonths = Array.from(monthMap.keys()).sort();
  const fullMonths: { ym: string; total: number }[] = [];
  const droppedMonths: string[] = [];

  for (const ym of sortedMonths) {
    const entry = monthMap.get(ym)!;
    const daysInMonth = getDaysInMonth(entry.year, entry.month - 1);
    if (entry.dates.size / daysInMonth >= 0.8) {
      fullMonths.push({ ym, total: entry.total });
    } else {
      droppedMonths.push(ym);
    }
  }

  return {
    fullMonths,
    droppedMonths,
  };
}

export function getOverview(rows?: SaleRow[]) {
  const data = rows || getSalesRows();
  if (data.length === 0) {
    throw new Error('No dataset has been uploaded yet.');
  }

  let totalSales = 0;
  let totalQuantity = 0;
  let minDate = data[0].date;
  let maxDate = data[0].date;

  const monthMap = new Map<
    string,
    {
      revenue: number;
      units: number;
      orders: number;
      dates: Set<string>;
      year: number;
      month: number;
    }
  >();

  const categoryMap = new Map<string, number>();

  for (const row of data) {
    totalSales += row.total_amount;
    totalQuantity += row.quantity;
    if (row.date < minDate) minDate = row.date;
    if (row.date > maxDate) maxDate = row.date;

    const ym = row.date.slice(0, 7);
    if (!monthMap.has(ym)) {
      const [y, m] = ym.split('-').map(Number);
      monthMap.set(ym, {
        revenue: 0,
        units: 0,
        orders: 0,
        dates: new Set(),
        year: y,
        month: m,
      });
    }
    const mEntry = monthMap.get(ym)!;
    mEntry.revenue += row.total_amount;
    mEntry.units += row.quantity;
    mEntry.orders += 1;
    mEntry.dates.add(row.date);

    categoryMap.set(row.product_category, (categoryMap.get(row.product_category) || 0) + row.total_amount);
  }

  const sortedMonths = Array.from(monthMap.keys()).sort();
  const monthly = sortedMonths.map((ym) => {
    const entry = monthMap.get(ym)!;
    const daysInMonth = getDaysInMonth(entry.year, entry.month - 1);
    const partial = entry.dates.size / daysInMonth < 0.8;
    return {
      month: ym,
      total_revenue: Math.round(entry.revenue * 100) / 100,
      avg_revenue: Math.round((entry.revenue / entry.orders) * 100) / 100,
      units: entry.units,
      orders: entry.orders,
      partial,
    };
  });

  const fullMonths = monthly.filter((m) => !m.partial);

  let trends: {
    revenue?: number;
    units?: number;
    transactions?: number;
    avg?: number;
    label?: string;
  } = {};

  if (fullMonths.length >= 2) {
    const last = fullMonths[fullMonths.length - 1];
    const prev = fullMonths[fullMonths.length - 2];
    const pct = (a: number, b: number) => (b ? Math.round(((a - b) / b) * 1000) / 10 : 0);

    trends = {
      revenue: pct(last.total_revenue, prev.total_revenue),
      units: pct(last.units, prev.units),
      transactions: pct(last.orders, prev.orders),
      avg: pct(last.avg_revenue, prev.avg_revenue),
      label: `${last.month} vs ${prev.month}`,
    };
  }

  // Weekly series: bucket by 7-day windows or ISO week ending dates
  const dailyRev = new Map<string, number>();
  for (const row of data) {
    dailyRev.set(row.date, (dailyRev.get(row.date) || 0) + row.total_amount);
  }

  const sortedDates = Array.from(dailyRev.keys()).sort();
  const weekly: { date: string; revenue: number }[] = [];
  if (sortedDates.length > 0) {
    let weekEnd = new Date(sortedDates[0]);
    // set to end of current week (e.g. Sunday)
    const day = weekEnd.getUTCDay();
    const diff = (7 - day) % 7;
    weekEnd.setUTCDate(weekEnd.getUTCDate() + diff);

    let currentWeekRev = 0;
    const maxD = new Date(maxDate);

    for (const dStr of sortedDates) {
      const d = new Date(dStr);
      while (d > weekEnd && weekEnd <= maxD) {
        weekly.push({
          date: weekEnd.toISOString().slice(0, 10),
          revenue: Math.round(currentWeekRev * 100) / 100,
        });
        currentWeekRev = 0;
        weekEnd.setUTCDate(weekEnd.getUTCDate() + 7);
      }
      currentWeekRev += dailyRev.get(dStr)!;
    }
    if (currentWeekRev > 0) {
      weekly.push({
        date: weekEnd.toISOString().slice(0, 10),
        revenue: Math.round(currentWeekRev * 100) / 100,
      });
    }
  }

  // Categories sorted
  const categories = Array.from(categoryMap.entries())
    .map(([cat, rev]) => ({ category: cat, sales: Math.round(rev * 100) / 100 }))
    .sort((a, b) => b.sales - a.sales);

  // Age segments: 18-24, 25-34, 35-44, 45-54, 55+
  const ageBuckets = [
    { label: '18-24', min: 18, max: 24, count: 0, revenue: 0 },
    { label: '25-34', min: 25, max: 34, count: 0, revenue: 0 },
    { label: '35-44', min: 35, max: 44, count: 0, revenue: 0 },
    { label: '45-54', min: 45, max: 54, count: 0, revenue: 0 },
    { label: '55+', min: 55, max: 200, count: 0, revenue: 0 },
  ];

  const genderMap = new Map<string, { count: number; revenue: number }>();

  for (const row of data) {
    for (const b of ageBuckets) {
      if (row.age >= b.min && row.age <= b.max) {
        b.count++;
        b.revenue += row.total_amount;
        break;
      }
    }

    const g = row.gender || 'Other';
    if (!genderMap.has(g)) genderMap.set(g, { count: 0, revenue: 0 });
    const gEntry = genderMap.get(g)!;
    gEntry.count++;
    gEntry.revenue += row.total_amount;
  }

  const ageSegments = ageBuckets.map((b) => ({
    segment: b.label,
    count: b.count,
    revenue: Math.round(b.revenue * 100) / 100,
  }));

  const genderSegments = Array.from(genderMap.entries()).map(([g, v]) => ({
    segment: g,
    count: v.count,
    revenue: Math.round(v.revenue * 100) / 100,
  }));

  return {
    dataset: {
      rows: data.length,
      start: minDate,
      end: maxDate,
    },
    kpis: {
      total_sales: Math.round(totalSales * 100) / 100,
      total_quantity: totalQuantity,
      total_transactions: data.length,
      average_transaction: Math.round((totalSales / data.length) * 100) / 100,
    },
    trends,
    weekly,
    monthly: monthly.map((m) => ({
      month: m.month,
      total_revenue: m.total_revenue,
      avg_revenue: m.avg_revenue,
      partial: m.partial,
    })),
    categories,
    segments: {
      age: ageSegments,
      gender: genderSegments,
    },
  };
}

export function getSalesAnalysis(rows?: SaleRow[]) {
  const data = rows || getSalesRows();
  const ov = getOverview(data);
  const total = ov.kpis.total_sales;

  // Stacked monthly category revenue for full months
  const { fullMonths, droppedMonths } = getMonthlyHistory(data);
  const fullYMs = new Set(fullMonths.map((m) => m.ym));

  const allCategories = Array.from(new Set(data.map((r) => r.product_category))).sort();
  const stackedMap = new Map<string, Record<string, number>>();

  for (const ym of fullYMs) {
    stackedMap.set(ym, {});
    for (const cat of allCategories) {
      stackedMap.get(ym)![cat] = 0;
    }
  }

  const catAgg = new Map<string, { revenue: number; units: number; orders: number }>();
  for (const cat of allCategories) {
    catAgg.set(cat, { revenue: 0, units: 0, orders: 0 });
  }

  // Weekday daily revenue: 0=Mon, 1=Tue, ..., 6=Sun
  const weekdayRev = [0, 0, 0, 0, 0, 0, 0];
  const weekdayDates = [new Set<string>(), new Set<string>(), new Set<string>(), new Set<string>(), new Set<string>(), new Set<string>(), new Set<string>()];

  for (const row of data) {
    const ym = row.date.slice(0, 7);
    if (fullYMs.has(ym)) {
      stackedMap.get(ym)![row.product_category] += row.total_amount;
    }

    const c = catAgg.get(row.product_category)!;
    c.revenue += row.total_amount;
    c.units += row.quantity;
    c.orders += 1;

    // Date day of week: getUTCDay() gives 0=Sun, 1=Mon, ..., 6=Sat
    // Convert to 0=Mon ... 6=Sun
    const dateObj = new Date(row.date);
    const day = (dateObj.getUTCDay() + 6) % 7;
    weekdayRev[day] += row.total_amount;
    weekdayDates[day].add(row.date);
  }

  const stackedMonths = Array.from(stackedMap.keys()).sort();
  const stackedSeries = allCategories.map((cat) => ({
    category: cat,
    values: stackedMonths.map((m) => Math.round((stackedMap.get(m)?.[cat] || 0) * 100) / 100),
  }));

  const categories = allCategories
    .map((name) => {
      const r = catAgg.get(name)!;
      return {
        category: name,
        revenue: Math.round(r.revenue * 100) / 100,
        share: total ? Math.round((r.revenue / total) * 1000) / 10 : 0,
        units: r.units,
        orders: r.orders,
        avg_order: r.orders ? Math.round((r.revenue / r.orders) * 100) / 100 : 0,
      };
    })
    .sort((a, b) => b.revenue - a.revenue);

  const weekday = WEEKDAYS.map((dayName, idx) => {
    const daysCount = weekdayDates[idx].size || 1;
    return {
      day: dayName,
      avg_daily_revenue: Math.round((weekdayRev[idx] / daysCount) * 100) / 100,
    };
  });

  const monthlyFull = ov.monthly.filter((m) => !m.partial);

  // Generate automated natural language business insights
  const insights: string[] = [];
  if (categories.length >= 2) {
    const top = categories[0];
    const low = categories[categories.length - 1];
    insights.push(`${top.category} leads with ${top.share}% of revenue; ${low.category} trails at ${low.share}%.`);
  }

  if (monthlyFull.length > 0) {
    const sortedByRev = [...monthlyFull].sort((a, b) => b.total_revenue - a.total_revenue);
    const best = sortedByRev[0];
    const weak = sortedByRev[sortedByRev.length - 1];
    const formatMY = (ym: string) => {
      const [y, m] = ym.split('-');
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return `${monthNames[Number(m) - 1]} ${y}`;
    };
    insights.push(
      `Best month was ${formatMY(best.month)} (₹${Math.round(best.total_revenue).toLocaleString('en-IN')}); weakest was ${formatMY(weak.month)} (₹${Math.round(weak.total_revenue).toLocaleString('en-IN')}).`
    );
  }

  if (weekday.length > 0) {
    const bestDay = [...weekday].sort((a, b) => b.avg_daily_revenue - a.avg_daily_revenue)[0];
    insights.push(
      `${bestDay.day} is the strongest weekday, averaging ₹${Math.round(bestDay.avg_daily_revenue).toLocaleString('en-IN')} per day.`
    );
  }

  return {
    trend: {
      weekly: ov.weekly,
      monthly: monthlyFull,
    },
    stacked: {
      months: stackedMonths,
      series: stackedSeries,
    },
    categories,
    weekday,
    insights,
    partial_months_excluded: droppedMonths,
  };
}

export function getForecast(rows?: SaleRow[]) {
  const data = rows || getSalesRows();
  const { fullMonths, droppedMonths } = getMonthlyHistory(data);

  const HORIZON = 6;
  const MIN_MONTHS = 6;
  const BACKTEST_MONTHS = 3;

  if (fullMonths.length < MIN_MONTHS) {
    throw new Error(`Need at least ${MIN_MONTHS} full months of data to forecast; found ${fullMonths.length}.`);
  }

  const y = fullMonths.map((m) => m.total);
  const n = y.length;

  // Model 1: Linear Regression
  const linearNext = (history: number[], steps: number): number[] => {
    const predictor = fitLinear(history);
    const result: number[] = [];
    for (let s = 0; s < steps; s++) {
      result.push(predictor(history.length + s));
    }
    return result;
  };

  // Model 2: Recent 3-month average
  const recentMeanNext = (history: number[], steps: number): number[] => {
    const last3 = history.slice(-3);
    const avg = mean(last3);
    return Array(steps).fill(avg);
  };

  const models: Record<string, (h: number[], steps: number) => number[]> = {
    'Linear trend': linearNext,
    'Recent 3-month average': recentMeanNext,
  };

  const scores: Record<string, number> = {};
  const errors: Record<string, number[]> = {};

  for (const [name, fn] of Object.entries(models)) {
    const errs: number[] = [];
    for (let i = n - BACKTEST_MONTHS; i < n; i++) {
      const train = y.slice(0, i);
      const pred = fn(train, 1)[0];
      const actual = y[i];
      errs.push(actual - pred);
    }
    errors[name] = errs;

    // MAPE over backtest months
    const actuals = y.slice(-BACKTEST_MONTHS);
    const mape = mean(errs.map((e, idx) => Math.abs(e) / actuals[idx]));
    scores[name] = mape;
  }

  // Pick model with lowest MAPE
  let bestModel = 'Linear trend';
  let lowestMape = Infinity;
  for (const [name, score] of Object.entries(scores)) {
    if (score < lowestMape) {
      lowestMape = score;
      bestModel = name;
    }
  }

  const bestErrors = errors[bestModel];
  const sigma = bestErrors.length > 1 ? stdDev(bestErrors, 1) : 0.15 * mean(y);
  const band = 1.28 * sigma; // ~80% prediction interval

  const preds = models[bestModel](y, HORIZON).map((v) => Math.max(0, v));

  // Determine next month string
  const lastYM = fullMonths[fullMonths.length - 1].ym;
  const [lastY, lastM] = lastYM.split('-').map(Number);

  const forecastRows: { date: string; predicted: number; lower: number; upper: number }[] = [];

  for (let i = 1; i <= HORIZON; i++) {
    const nextDateObj = new Date(Date.UTC(lastY, lastM - 1 + i, 1));
    const nextYM = nextDateObj.toISOString().slice(0, 7);
    const val = preds[i - 1];
    forecastRows.push({
      date: nextYM,
      predicted: Math.round(val * 100) / 100,
      lower: Math.round(Math.max(0, val - band) * 100) / 100,
      upper: Math.round((val + band) * 100) / 100,
    });
  }

  const history = fullMonths.map((m) => ({
    date: m.ym,
    sales: Math.round(m.total * 100) / 100,
  }));

  const mapePct = Math.round(lowestMape * 1000) / 10;
  const accuracy = Math.round(Math.max(0, 100 - mapePct) * 10) / 10;

  return {
    history,
    data: forecastRows,
    model: bestModel,
    mape: mapePct,
    accuracy,
    next_month_predicted: forecastRows[0].predicted,
    partial_months_excluded: droppedMonths,
  };
}

export function getAnomalies(rows?: SaleRow[], limit = 500, threshold = 2.0) {
  const data = rows || getSalesRows();
  const dailyMap = new Map<string, number>();

  for (const row of data) {
    dailyMap.set(row.date, (dailyMap.get(row.date) || 0) + row.total_amount);
  }

  const sortedDates = Array.from(dailyMap.keys()).sort();
  if (sortedDates.length < 14) {
    return { data: [], total: 0, threshold };
  }

  const dailyVals = sortedDates.map((d) => dailyMap.get(d)!);

  // 31-day rolling median (centered, min 7 periods)
  const windowRadius = 15;
  const expected: number[] = [];
  const residuals: number[] = [];

  for (let i = 0; i < sortedDates.length; i++) {
    const start = Math.max(0, i - windowRadius);
    const end = Math.min(sortedDates.length, i + windowRadius + 1);
    const windowSlice = dailyVals.slice(start, end);
    const exp = windowSlice.length >= 7 ? median(windowSlice) : dailyVals[i];
    expected.push(exp);
    residuals.push(dailyVals[i] - exp);
  }

  const medResid = median(residuals);
  const absDeviations = residuals.map((r) => Math.abs(r - medResid));
  let mad = median(absDeviations);
  if (mad === 0) {
    mad = stdDev(residuals) || 1.0;
  }

  const cutoff = Math.max(1.0, threshold);
  const flagged: {
    date: string;
    value: number;
    expected: number;
    deviation: string;
    severity: 'High' | 'Medium';
    score: number;
    absScore: number;
  }[] = [];

  for (let i = 0; i < sortedDates.length; i++) {
    const z = (0.6745 * (residuals[i] - medResid)) / mad;
    if (Math.abs(z) >= cutoff) {
      const val = dailyVals[i];
      const exp = expected[i];
      const pct = exp ? ((val - exp) / exp) * 100 : 0;
      flagged.push({
        date: sortedDates[i],
        value: Math.round(val * 100) / 100,
        expected: Math.round(exp * 100) / 100,
        deviation: `${pct >= 0 ? '+' : ''}${Math.round(pct)}%`,
        severity: Math.abs(z) >= cutoff * 1.25 ? 'High' : 'Medium',
        score: Math.round(z * 10) / 10,
        absScore: Math.abs(z),
      });
    }
  }

  flagged.sort((a, b) => b.absScore - a.absScore);

  const resultData = flagged.slice(0, limit).map(({ absScore, ...item }) => item);

  return {
    data: resultData,
    total: flagged.length,
    threshold: cutoff,
  };
}
